<?php 

?>



<!DOCTYPE html>
<html>


<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
<title>Qualify For Today's Low Mortgage Rates. Takes 30 Seconds. | Ablending.com</title>
<meta name="description" content="Qualify For Today's Low Mortgage Rates. Takes 30 Seconds.">
<meta name="keywords" content="qualify compare mortgage quotes lenders">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jquerymobile/1.4.5/jquery.mobile.min.css">
<link rel="stylesheet" href="//code.jquery.com/mobile/1.4.5/jquery.mobile.structure-1.4.5.min.css" />
<link rel="stylesheet" href="css/style.css" />
<link rel="stylesheet" href="1css/modal.css" />

<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-101420116-2"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-101420116-2');
</script>

</head>
<body>
<div id="loader"></div>
<div data-role="page" id="page-div">
<div data-role="content" data-theme="a"> <img src="img/1logo.png" width="146" height="82" id="Ablending" title="Ablending.com">
<div class="title">
<h1>We have received your submission.</h1>
<h2><strong>One of our colleagues will get back to you shortly.</h2>
</div>
<div class="error-message"></div>

<div><img src="img/mark.png"></div>
<div>Mark Ventrone Founder of ABLEnding, Inc.</div>
<br>
<div class="security"> <img src="img/bbb-icon.gif"> <span>BBB</span> Accredited Business |<img src="img/lock-icon.gif"> Privacy <strong>Protected</strong> </div>
</form>



<div class="tollfree">Talk with us <a href="tel:8668234462 " class="tollfreephone">(866) 823-4462 </a></div>

<p class="disclaimer-text"> Click here to view our <a href="https://www.Ablending.com.com/privacy-policy/" title="Privacy Policy" data-ajax="false" target="_blank">Privacy Statement</a> and <a href="https://www.Ablending.com.com/disclosures-terms-conditions/" title="Terms & Conditions" data-ajax="false" target="_blank">Terms</a> </p>
<p class="lenders"> <a href="https://ablending.com/contact-us/" title="Contact us" data-ajax="false">Contact Us</a></p>
</div>


<script src="http://maps.googleapis.com/maps/api/js?libraries=places&amp;key=AIzaSyC5SMZM-jNQVc9IWqwWPeeRJKiKYTiPsGo"></script>
<script src="vendor/jquery/jquery-1.11.1.min.js"></script>
<script src="vendor/jquery-mobile/jquery.mobile-1.4.5.min.js"></script>
<script src="vendor/jquery-validate/jquery.validate-1.11.1.min.js"></script>
<script src="vendor/jquery-maskedinput/jquery.maskedinput.js"></script>
<script src="vendor/geocomplete/jquery.geocomplete.min.js"></script>
<script src="vendor/ouibounce/ouibounce.js"></script>
<script src="js/functions.js"></script>
<script id="LeadiDscript" type="text/javascript">
  (
    function() { 
      var s = document.createElement('script'); 
      s.id = 'LeadiDscript_campaign'; 
      s.type = 'text/javascript'; 
      s.async = true; 
      s.src = (document.location.protocol + '//d1tprjo2w7krrh.cloudfront.net/campaign/36210b05-1ee3-8224-8678-e88d15c91789.js'); 
      var LeadiDscript = document.getElementById('LeadiDscript'); 
      LeadiDscript.parentNode.insertBefore(s, LeadiDscript);
    }
  )();
</script>





<script type="application/javascript">
		(function(w,d,t,r,u){w[u]=w[u]||[];
		w[u].push({'projectId':'10000','properties':{'pixelId':'10048403'}});
		var s=d.createElement(t);
		s.src=r;
		s.async=true;
		s.onload=s.onreadystatechange=function(){
			var y,rs=this.readyState,c=w[u];
			if(rs&&rs!="complete"&&rs!="loaded"){return}
			try{
				y=YAHOO.ywa.I13N.fireBeacon;
				w[u]=[];
				w[u].push=function(p){y([p])};
				y(c)}catch(e){}};
				var scr=d.getElementsByTagName(t)[0],par=scr.parentNode;
				par.insertBefore(s,scr)
			}
		)
		(window,document,"script","js/ytc.js","dotq");
  </script>

</body>

</html>